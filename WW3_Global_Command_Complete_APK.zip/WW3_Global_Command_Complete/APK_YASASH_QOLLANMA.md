# WW3: GLOBAL COMMAND — TO'LIQ UNITY APK LOYIHASI

Ushbu arxiv ichida **Android APK** chiqarish uchun barcha tizimlar birlashtirilgan:
1. **Avtomatik Rasm Yuklash va Offline Kesh (`Assets/Scripts/Core/PortraitLoader.cs`)**:
   - O'yin telefonda birinchi marta ochilganda barcha generallar va prezidentlarning (Ali Xomanaiy, Sobir Rahimov, Jukov, Rommel, Mirziyoyev, Tramp, Putin, Si Szinpin, Erdo'g'an, Zelenskiy, Netanyaxu va boshqalar) rasmlarini Wikipedia bazasidan avtomatik yuklab olib, telefon xotirasiga saqlaydi. Keyingi safar internetsiz ham ishlaydi.
2. **Taktik Geksagonal Xarita (`Assets/Scripts/Map/HexMapManager.cs`)**:
   - Toshkent, Tehron, Vashington, Moskva va strategik frontlarni o'z ichiga olgan olti burchakli xarita generatori.
3. **Jang, Raketa Animatsiyasi va Ovoz Tizimi (`Assets/Scripts/Combat/`)**:
   - Ballistik raketa uchish trayektoriyasi, PVO lazer himoyasi, kamikadze dronlar (UAV) va yadroviy zarba effektlari.
4. **Diplomatiya va Ittifoqlar (`Assets/Scripts/Diplomacy/DiplomacySystem.cs`)**:
   - NATO, BRIKS, Qarshilik o'qi va Betaraf davlatlar o'rtasida urush e'lon qilish, sanksiyalar va harbiy-moliyaviy yordam yuborish.
5. **Harbiy Shtab Interfeysi (`Assets/Scripts/UI/WarRoomUIController.cs`)**:
   - Oltin, neft, yadro kallaklari va qo'mondonlarning 5 yulduzli kartochkalarini boshqarish paneli.

## 5 Daqiqada APK Chiqarish Tartibi:
1. Kompyuterda **Unity Hub** orqali yangi **3D (URP yoki Core)** loyiha oching.
2. Ushbu arxivdagi `Assets` papkasini loyihangiz ichidagi `Assets` papkasi ustiga tashlang.
3. Unity menyusidan **File -> Build Settings -> Android -> Switch Platform** tugmasini bosing.
4. Bo'sh sahnada bitta `GameManager` obyekti yarating va unga `CommanderDatabase`, `PortraitLoader`, `HexMapManager`, `BattleEngine`, `DiplomacySystem` hamda `WarRoomUIController` skriptlarini biriktiring.
5. **Build** tugmasini bosing — tayyor `WW3_Global_Command.apk` fayli yaratiladi!
