using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.UI;

namespace WW3Command.Core
{
    public class PortraitLoader : MonoBehaviour
    {
        public static PortraitLoader Instance { get; private set; }
        private Dictionary<string, Sprite> memoryCache = new Dictionary<string, Sprite>();
        private string cacheFolder;

        private void Awake()
        {
            if (Instance == null)
            {
                Instance = this;
                DontDestroyOnLoad(gameObject);
                cacheFolder = Path.Combine(Application.persistentDataPath, "CommanderPortraits");
                if (!Directory.Exists(cacheFolder)) Directory.CreateDirectory(cacheFolder);
            }
            else Destroy(gameObject);
        }

        public void LoadPortrait(CommanderProfile profile, Image targetImage)
        {
            if (profile == null || targetImage == null) return;

            if (memoryCache.ContainsKey(profile.id))
            {
                targetImage.sprite = memoryCache[profile.id];
                return;
            }

            string localPath = Path.Combine(cacheFolder, profile.id + ".png");
            if (File.Exists(localPath))
            {
                byte[] bytes = File.ReadAllBytes(localPath);
                Texture2D tex = new Texture2D(2, 2);
                if (tex.LoadImage(bytes))
                {
                    Sprite sp = Sprite.Create(tex, new Rect(0, 0, tex.width, tex.height), new Vector2(0.5f, 0.5f));
                    memoryCache[profile.id] = sp;
                    targetImage.sprite = sp;
                    return;
                }
            }

            StartCoroutine(DownloadFromWikipedia(profile, targetImage, localPath));
        }

        private IEnumerator DownloadFromWikipedia(CommanderProfile profile, Image targetImage, string savePath)
        {
            string apiUrl = $"https://en.wikipedia.org/api/rest_v1/page/summary/{profile.wikiPageTitle}";
            using (UnityWebRequest req = UnityWebRequest.Get(apiUrl))
            {
                req.SetRequestHeader("User-Agent", "WW3GlobalCommandAPK/1.0");
                yield return req.SendWebRequest();

                if (req.result == UnityWebRequest.Result.Success)
                {
                    string json = req.downloadHandler.text;
                    string imgUrl = ExtractThumbnailUrl(json);
                    if (!string.IsNullOrEmpty(imgUrl))
                    {
                        using (UnityWebRequest imgReq = UnityWebRequestTexture.GetTexture(imgUrl))
                        {
                            yield return imgReq.SendWebRequest();
                            if (imgReq.result == UnityWebRequest.Result.Success)
                            {
                                Texture2D tex = DownloadHandlerTexture.GetContent(imgReq);
                                File.WriteAllBytes(savePath, tex.EncodeToPNG());
                                Sprite sp = Sprite.Create(tex, new Rect(0, 0, tex.width, tex.height), new Vector2(0.5f, 0.5f));
                                memoryCache[profile.id] = sp;
                                if (targetImage != null) targetImage.sprite = sp;
                            }
                        }
                    }
                }
            }
        }

        private string ExtractThumbnailUrl(string json)
        {
            int thumbIdx = json.IndexOf(""thumbnail"");
            if (thumbIdx == -1) return null;
            int srcIdx = json.IndexOf(""source":"", thumbIdx);
            if (srcIdx == -1) return null;
            srcIdx += 10;
            int endIdx = json.IndexOf(""", srcIdx);
            if (endIdx == -1) return null;
            return json.Substring(srcIdx, endIdx - srcIdx).Replace("\/", "/");
        }
    }
}
