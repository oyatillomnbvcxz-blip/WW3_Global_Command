using System;
using System.Collections.Generic;
using UnityEngine;

namespace WW3Command.Core
{
    public enum Faction { USA, Russia, Iran, China, Ukraine, Israel, Turkey, Uzbekistan, Germany_WW2, USSR_WW2, Allies_WW2, Axis_WW2 }
    public enum Era { WW2, ColdWar, Modern_WW3 }
    public enum LeaderRole { President, SupremeLeader, FieldMarshal, General, Admiral }

    [Serializable]
    public class CommanderProfile
    {
        public string id;
        public string fullName;
        public string title;
        public Faction faction;
        public Era era;
        public LeaderRole role;
        public string wikiPageTitle; // Avtomatik rasm yuklash uchun Wikipedia sahifa nomi
        
        [Range(0, 5)] public int infantryStars;
        [Range(0, 5)] public int armorStars;
        [Range(0, 5)] public int artilleryStars;
        [Range(0, 5)] public int airForceStars;
        [Range(0, 5)] public int navyStars;
        [Range(0, 5)] public int mobilityStars;

        public string specialSkillName;
        public string specialSkillDesc;
        public float attackMultiplier = 1.0f;
        public float defenseMultiplier = 1.0f;
        public int economyBonusPerTurn = 0;
    }

    public class CommanderDatabase : MonoBehaviour
    {
        public static CommanderDatabase Instance { get; private set; }
        public List<CommanderProfile> commanders = new List<CommanderProfile>();

        private void Awake()
        {
            if (Instance == null) { Instance = this; DontDestroyOnLoad(gameObject); LoadAllCommanders(); }
            else { Destroy(gameObject); }
        }

        public void LoadAllCommanders()
        {
            commanders.Clear();

            // --- ERON YETAKCHILARI VA QO'MONDONLARI ---
            commanders.Add(new CommanderProfile {
                id = "ir_khamenei", fullName = "Ali Xomanaiy", title = "Eron Oliy Rahbari",
                faction = Faction.Iran, era = Era.Modern_WW3, role = LeaderRole.SupremeLeader,
                wikiPageTitle = "Ali_Khamenei",
                infantryStars = 3, armorStars = 2, artilleryStars = 5, airForceStars = 4, navyStars = 4, mobilityStars = 3,
                specialSkillName = "Asimmetrik Mudofaa", specialSkillDesc = "Ballistik raketalar va dronlar hujumi +30%, shahar mudofaasi +25%",
                attackMultiplier = 1.25f, defenseMultiplier = 1.25f, economyBonusPerTurn = 120
            });
            commanders.Add(new CommanderProfile {
                id = "ir_mojtaba", fullName = "Mojtaba Xomanaiy", title = "Strategik Qo'mondon",
                faction = Faction.Iran, era = Era.Modern_WW3, role = LeaderRole.General,
                wikiPageTitle = "Mojtaba_Khamenei",
                infantryStars = 4, armorStars = 3, artilleryStars = 4, airForceStars = 3, navyStars = 3, mobilityStars = 4,
                specialSkillName = "Quds Tarmog'i", specialSkillDesc = "Partizan va dron zarbalari narxi -20%",
                attackMultiplier = 1.18f, defenseMultiplier = 1.20f, economyBonusPerTurn = 80
            });
            commanders.Add(new CommanderProfile {
                id = "ir_soleimani", fullName = "Qosim Sulaymoniy", title = "General-leytenant",
                faction = Faction.Iran, era = Era.Modern_WW3, role = LeaderRole.General,
                wikiPageTitle = "Qasem_Soleimani",
                infantryStars = 5, armorStars = 4, artilleryStars = 4, airForceStars = 3, navyStars = 3, mobilityStars = 5,
                specialSkillName = "Tungi Bo'ri", specialSkillDesc = "Taktik manyovr va kutilmagan hujum +35%",
                attackMultiplier = 1.32f, defenseMultiplier = 1.18f
            });

            // --- 2-JAHON URUSHI AFSONALARI (SOBIR RAHIMOV VA BOSHQALAR) ---
            commanders.Add(new CommanderProfile {
                id = "ww2_rahimov", fullName = "Sobir Rahimov", title = "General-mayor (Temir General)",
                faction = Faction.Uzbekistan, era = Era.WW2, role = LeaderRole.General,
                wikiPageTitle = "Sabir_Rakhimov",
                infantryStars = 5, armorStars = 4, artilleryStars = 4, airForceStars = 2, navyStars = 1, mobilityStars = 5,
                specialSkillName = "Temir Iroda", specialSkillDesc = "Piyoda va gvardiya qo'shinlari hujumi +35%, qurshovdan chiqish bonusi",
                attackMultiplier = 1.35f, defenseMultiplier = 1.30f
            });
            commanders.Add(new CommanderProfile {
                id = "ww2_zhukov", fullName = "Georgiy Jukov", title = "Sovet Ittifoqi Marshali",
                faction = Faction.USSR_WW2, era = Era.WW2, role = LeaderRole.FieldMarshal,
                wikiPageTitle = "Georgy_Zhukov",
                infantryStars = 5, armorStars = 5, artilleryStars = 5, airForceStars = 3, navyStars = 2, mobilityStars = 4,
                specialSkillName = "G'alaba Marshali", specialSkillDesc = "Barcha quruqlik qo'shinlari zarbasi +30%",
                attackMultiplier = 1.35f, defenseMultiplier = 1.25f
            });
            commanders.Add(new CommanderProfile {
                id = "ww2_rommel", fullName = "Ervin Rommel", title = "Generalfeldmarshal",
                faction = Faction.Germany_WW2, era = Era.WW2, role = LeaderRole.FieldMarshal,
                wikiPageTitle = "Erwin_Rommel",
                infantryStars = 4, armorStars = 5, artilleryStars = 4, airForceStars = 3, navyStars = 2, mobilityStars = 5,
                specialSkillName = "Sahro Tulkisi", specialSkillDesc = "Tank diviziyalari tezligi +2 katak, hujum +35%",
                attackMultiplier = 1.35f, defenseMultiplier = 1.15f
            });
            commanders.Add(new CommanderProfile {
                id = "ww2_patton", fullName = "Jorj Patton", title = "Armiya Generali",
                faction = Faction.Allies_WW2, era = Era.WW2, role = LeaderRole.General,
                wikiPageTitle = "George_S._Patton",
                infantryStars = 4, armorStars = 5, artilleryStars = 4, airForceStars = 3, navyStars = 2, mobilityStars = 5,
                specialSkillName = "Chaqmoq Zarba", specialSkillDesc = "Zirhli texnika hujumi +32%",
                attackMultiplier = 1.32f, defenseMultiplier = 1.12f
            });
            commanders.Add(new CommanderProfile {
                id = "ww2_rokossovsky", fullName = "Konstantin Rokossovskiy", title = "Marshal",
                faction = Faction.USSR_WW2, era = Era.WW2, role = LeaderRole.FieldMarshal,
                wikiPageTitle = "Konstantin_Rokossovsky",
                infantryStars = 4, armorStars = 5, artilleryStars = 5, airForceStars = 3, navyStars = 1, mobilityStars = 4,
                specialSkillName = "Bagration Zarbasi", specialSkillDesc = "Artilleriya va tank hamkorligi +30%",
                attackMultiplier = 1.30f, defenseMultiplier = 1.22f
            });
            commanders.Add(new CommanderProfile {
                id = "ww2_yamamoto", fullName = "Isoroku Yamamoto", title = "Flot Admirali",
                faction = Faction.Axis_WW2, era = Era.WW2, role = LeaderRole.Admiral,
                wikiPageTitle = "Isoroku_Yamamoto",
                infantryStars = 2, armorStars = 1, artilleryStars = 3, airForceStars = 5, navyStars = 5, mobilityStars = 5,
                specialSkillName = "Avianosec Zarbasi", specialSkillDesc = "Dengiz va aviazarbalar +40%",
                attackMultiplier = 1.38f, defenseMultiplier = 1.15f
            });

            // --- ZAMONAVIY PREZIDENTLAR VA WW3 QO'MONDONLARI ---
            commanders.Add(new CommanderProfile {
                id = "uz_mirziyoyev", fullName = "Shavkat Mirziyoyev", title = "O'zbekiston Prezidenti",
                faction = Faction.Uzbekistan, era = Era.Modern_WW3, role = LeaderRole.President,
                wikiPageTitle = "Shavkat_Mirziyoyev",
                infantryStars = 3, armorStars = 3, artilleryStars = 3, airForceStars = 3, navyStars = 2, mobilityStars = 4,
                specialSkillName = "Markaziy Osiyo Barqarorligi", specialSkillDesc = "Diplomatiya +40%, har yurishda +200 oltin",
                attackMultiplier = 1.15f, defenseMultiplier = 1.25f, economyBonusPerTurn = 200
            });
            commanders.Add(new CommanderProfile {
                id = "us_trump", fullName = "Donald Tramp", title = "AQSH Prezidenti",
                faction = Faction.USA, era = Era.Modern_WW3, role = LeaderRole.President,
                wikiPageTitle = "Donald_Trump",
                infantryStars = 3, armorStars = 4, artilleryStars = 4, airForceStars = 5, navyStars = 5, mobilityStars = 3,
                specialSkillName = "Superpower Iqtisodiyot", specialSkillDesc = "Har yurishda +300 oltin, aviatsiya narxi -15%",
                attackMultiplier = 1.22f, defenseMultiplier = 1.18f, economyBonusPerTurn = 300
            });
            commanders.Add(new CommanderProfile {
                id = "ru_putin", fullName = "Vladimir Putin", title = "Rossiya Prezidenti",
                faction = Faction.Russia, era = Era.Modern_WW3, role = LeaderRole.President,
                wikiPageTitle = "Vladimir_Putin",
                infantryStars = 4, armorStars = 4, artilleryStars = 5, airForceStars = 4, navyStars = 4, mobilityStars = 3,
                specialSkillName = "Gipertovushli Qalqon", specialSkillDesc = "Raketalar va PVO samaradorligi +30%",
                attackMultiplier = 1.25f, defenseMultiplier = 1.28f, economyBonusPerTurn = 180
            });
            commanders.Add(new CommanderProfile {
                id = "cn_xi", fullName = "Si Szinpin", title = "XXR Raisi",
                faction = Faction.China, era = Era.Modern_WW3, role = LeaderRole.President,
                wikiPageTitle = "Xi_Jinping",
                infantryStars = 4, armorStars = 4, artilleryStars = 4, airForceStars = 4, navyStars = 5, mobilityStars = 4,
                specialSkillName = "Sanoat Giganti", specialSkillDesc = "Qo'shin ishlab chiqarish tezligi +35%, +280 oltin",
                attackMultiplier = 1.20f, defenseMultiplier = 1.25f, economyBonusPerTurn = 280
            });
            commanders.Add(new CommanderProfile {
                id = "tr_erdogan", fullName = "Rejep Tayyip Erdo'g'an", title = "Turkiya Prezidenti",
                faction = Faction.Turkey, era = Era.Modern_WW3, role = LeaderRole.President,
                wikiPageTitle = "Recep_Tayyip_Erdo%C4%9Fan",
                infantryStars = 4, armorStars = 3, artilleryStars = 4, airForceStars = 5, navyStars = 4, mobilityStars = 4,
                specialSkillName = "Bayraktar Doktrinasi", specialSkillDesc = "Zarbdor dronlar (UAV) hujumi +40%",
                attackMultiplier = 1.28f, defenseMultiplier = 1.20f, economyBonusPerTurn = 160
            });
            commanders.Add(new CommanderProfile {
                id = "ua_zelensky", fullName = "Volodimir Zelenskiy", title = "Ukraina Prezidenti",
                faction = Faction.Ukraine, era = Era.Modern_WW3, role = LeaderRole.President,
                wikiPageTitle = "Volodymyr_Zelenskyy",
                infantryStars = 4, armorStars = 3, artilleryStars = 4, airForceStars = 3, navyStars = 3, mobilityStars = 4,
                specialSkillName = "Xalqaro Yordam", specialSkillDesc = "Ittifoqchilardan har yurishda +150 oltin va dronlar",
                attackMultiplier = 1.18f, defenseMultiplier = 1.30f, economyBonusPerTurn = 150
            });
            commanders.Add(new CommanderProfile {
                id = "il_netanyahu", fullName = "Binyamin Netanyaxu", title = "Isroil Bosh Vaziri",
                faction = Faction.Israel, era = Era.Modern_WW3, role = LeaderRole.President,
                wikiPageTitle = "Benjamin_Netanyahu",
                infantryStars = 4, armorStars = 4, artilleryStars = 4, airForceStars = 5, navyStars = 3, mobilityStars = 4,
                specialSkillName = "Temir Gumbaz (Iron Dome)", specialSkillDesc = "Havo hujumidan mudofaa (PVO) +45%",
                attackMultiplier = 1.25f, defenseMultiplier = 1.35f, economyBonusPerTurn = 170
            });
            commanders.Add(new CommanderProfile {
                id = "ua_zaluzhnyi", fullName = "Valeriy Zalujniy", title = "General",
                faction = Faction.Ukraine, era = Era.Modern_WW3, role = LeaderRole.General,
                wikiPageTitle = "Valerii_Zaluzhnyi",
                infantryStars = 5, armorStars = 4, artilleryStars = 5, airForceStars = 3, navyStars = 3, mobilityStars = 4,
                specialSkillName = "Zamonaviy Artilleriya", specialSkillDesc = "Uzoq masofali zarbalar aniqligi +30%",
                attackMultiplier = 1.28f, defenseMultiplier = 1.28f
            });
        }
    }
}
