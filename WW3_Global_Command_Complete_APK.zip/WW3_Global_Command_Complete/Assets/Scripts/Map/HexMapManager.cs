using System.Collections.Generic;
using UnityEngine;
using WW3Command.Core;

namespace WW3Command.Map
{
    public enum TerrainType { Plains, Mountains, Desert, City, Sea, NuclearWasteland }

    [System.Serializable]
    public class HexTileData
    {
        public int q;
        public int r;
        public string regionName;
        public TerrainType terrain;
        public Faction owner;
        public int cityLevel; // 0 = oddiy yer, 1-5 = strategik shahar
        public bool hasAirDefensePVO;
        public bool hasMissileSilo;
    }

    public class HexMapManager : MonoBehaviour
    {
        public static HexMapManager Instance { get; private set; }
        public GameObject hexTilePrefab;
        public float hexRadius = 1.0f;
        public Dictionary<Vector2Int, HexTileData> grid = new Dictionary<Vector2Int, HexTileData>();

        private void Awake() { Instance = this; }

        public Vector3 HexToWorld(int q, int r)
        {
            float x = hexRadius * (Mathf.Sqrt(3f) * q + Mathf.Sqrt(3f) / 2f * r);
            float z = hexRadius * (3f / 2f * r);
            return new Vector3(x, 0, z);
        }

        public void GenerateScenarioMap(string scenarioId)
        {
            grid.Clear();
            // 15x10 geksagonal front xaritasi
            for (int q = -7; q <= 7; q++)
            {
                for (int r = -5; r <= 5; r++)
                {
                    HexTileData tile = new HexTileData
                    {
                        q = q, r = r,
                        terrain = (Mathf.Abs(q) % 4 == 0) ? TerrainType.Mountains : TerrainType.Plains,
                        owner = q < -2 ? Faction.USA : (q > 2 ? Faction.Iran : Faction.Russia),
                        cityLevel = (q % 3 == 0 && r % 3 == 0) ? 3 : 0,
                        hasAirDefensePVO = (q % 4 == 0 && r % 2 == 0)
                    };
                    if (q == 0 && r == 0) { tile.regionName = "Toshkent (Bosh Shtab)"; tile.owner = Faction.Uzbekistan; tile.cityLevel = 5; }
                    if (q == 4 && r == -2) { tile.regionName = "Tehron"; tile.owner = Faction.Iran; tile.cityLevel = 5; tile.hasAirDefensePVO = true; }
                    if (q == -5 && r == 2) { tile.regionName = "Vashington / NATO Bazasi"; tile.owner = Faction.USA; tile.cityLevel = 5; }
                    if (q == 3 && r == 3) { tile.regionName = "Moskva"; tile.owner = Faction.Russia; tile.cityLevel = 5; }

                    grid[new Vector2Int(q, r)] = tile;
                    if (hexTilePrefab != null)
                    {
                        GameObject go = Instantiate(hexTilePrefab, HexToWorld(q, r), Quaternion.identity, transform);
                        go.name = $"Hex_{q}_{r}_{tile.regionName}";
                    }
                }
            }
        }
    }
}
