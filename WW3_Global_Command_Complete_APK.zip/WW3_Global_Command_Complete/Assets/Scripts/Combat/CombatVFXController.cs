using System.Collections;
using UnityEngine;
using WW3Command.Map;

namespace WW3Command.Combat
{
    public class CombatVFXController : MonoBehaviour
    {
        public GameObject missilePrefab;
        public GameObject explosionPrefab;
        public GameObject nuclearMushroomPrefab;
        public GameObject pvoLaserPrefab;
        public AudioSource sfxSource;
        public AudioClip missileLaunchClip;
        public AudioClip explosionClip;
        public AudioClip nuclearSirenClip;

        public void PlayMissileAndExplosion(Vector2Int fromHex, Vector2Int toHex)
        {
            Vector3 start = HexMapManager.Instance != null ? HexMapManager.Instance.HexToWorld(fromHex.x, fromHex.y) : Vector3.zero;
            Vector3 end = HexMapManager.Instance != null ? HexMapManager.Instance.HexToWorld(toHex.x, toHex.y) : Vector3.forward * 5f;
            StartCoroutine(AnimateProjectile(start, end, false));
        }

        public void PlayNuclearExplosion(Vector2Int targetHex)
        {
            Vector3 pos = HexMapManager.Instance != null ? HexMapManager.Instance.HexToWorld(targetHex.x, targetHex.y) : Vector3.zero;
            if (sfxSource != null && nuclearSirenClip != null) sfxSource.PlayOneShot(nuclearSirenClip);
            if (nuclearMushroomPrefab != null) Instantiate(nuclearMushroomPrefab, pos, Quaternion.identity);
        }

        public void PlayPVOInterceptEffect(Vector2Int hex)
        {
            Vector3 pos = HexMapManager.Instance != null ? HexMapManager.Instance.HexToWorld(hex.x, hex.y) : Vector3.zero;
            if (pvoLaserPrefab != null) Instantiate(pvoLaserPrefab, pos + Vector3.up * 1.5f, Quaternion.identity);
        }

        private IEnumerator AnimateProjectile(Vector3 start, Vector3 end, bool isNuke)
        {
            if (sfxSource != null && missileLaunchClip != null) sfxSource.PlayOneShot(missileLaunchClip);
            GameObject proj = missilePrefab != null ? Instantiate(missilePrefab, start, Quaternion.identity) : null;
            float duration = 0.65f;
            float elapsed = 0f;

            while (elapsed < duration)
            {
                elapsed += Time.deltaTime;
                float t = elapsed / duration;
                if (proj != null)
                {
                    Vector3 pos = Vector3.Lerp(start, end, t);
                    pos.y += Mathf.Sin(t * Mathf.PI) * 2.5f; // Ballistik yoy
                    proj.transform.position = pos;
                }
                yield return null;
            }

            if (proj != null) Destroy(proj);
            if (sfxSource != null && explosionClip != null) sfxSource.PlayOneShot(explosionClip);
            if (explosionPrefab != null) Instantiate(explosionPrefab, end, Quaternion.identity);
        }
    }
}
