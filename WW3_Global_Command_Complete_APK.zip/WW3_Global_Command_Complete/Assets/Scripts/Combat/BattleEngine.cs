using UnityEngine;
using WW3Command.Core;
using WW3Command.Combat;

namespace WW3Command.Combat
{
    public enum UnitType { SpecOpsInfantry, HeavyTankMBT, KamikazeDroneUAV, BallisticMissile, AirDefensePVO, StealthFighter, NuclearICBM }

    [System.Serializable]
    public class MilitaryUnit
    {
        public string unitName;
        public UnitType type;
        public Faction faction;
        public int maxHP = 100;
        public int currentHP = 100;
        public int baseAttack = 40;
        public int baseDefense = 25;
        public int range = 1;
        public int movement = 3;
        public CommanderProfile assignedCommander;
        public Vector2Int coords;
    }

    public class BattleEngine : MonoBehaviour
    {
        public static BattleEngine Instance { get; private set; }
        public CombatVFXController vfxController;

        private void Awake() { Instance = this; }

        public int ExecuteAttack(MilitaryUnit attacker, MilitaryUnit defender, bool targetHasPVO)
        {
            float atkBonus = attacker.assignedCommander != null ? attacker.assignedCommander.attackMultiplier : 1.0f;
            float defBonus = defender.assignedCommander != null ? defender.assignedCommander.defenseMultiplier : 1.0f;

            // Zamonaviy qurollar mexanikasi: Dron va Raketalarga qarshi PVO tizimi
            float pvoReduction = 1.0f;
            if (targetHasPVO && (attacker.type == UnitType.KamikazeDroneUAV || attacker.type == UnitType.BallisticMissile || attacker.type == UnitType.StealthFighter))
            {
                pvoReduction = 0.55f; // PVO zarbaning 45% qismini urib tushiradi
                if (vfxController != null) vfxController.PlayPVOInterceptEffect(defender.coords);
            }

            float rawDamage = (attacker.baseAttack * atkBonus * pvoReduction) - (defender.baseDefense * defBonus * 0.45f);
            int finalDamage = Mathf.Max(8, Mathf.RoundToInt(rawDamage * Random.Range(0.9f, 1.15f)));

            if (attacker.type == UnitType.NuclearICBM)
            {
                finalDamage = 250;
                if (vfxController != null) vfxController.PlayNuclearExplosion(defender.coords);
            }
            else if (vfxController != null)
            {
                vfxController.PlayMissileAndExplosion(attacker.coords, defender.coords);
            }

            defender.currentHP = Mathf.Max(0, defender.currentHP - finalDamage);
            return finalDamage;
        }
    }
}
