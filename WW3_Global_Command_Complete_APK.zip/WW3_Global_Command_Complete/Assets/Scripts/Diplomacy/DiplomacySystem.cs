using System.Collections.Generic;
using UnityEngine;
using WW3Command.Core;

namespace WW3Command.Diplomacy
{
    public enum DiplomaticStatus { Ally, Neutral, Sanctioned, AtWar }
    public enum GlobalBloc { NATO_West, BRICS_East, Resistance_Axis, NonAligned_CentralAsia }

    [System.Serializable]
    public class NationDiplomacy
    {
        public Faction faction;
        public GlobalBloc bloc;
        public int goldTreasury = 1000;
        public int oilReserves = 500;
        public int nuclearWarheads = 5;
        public Dictionary<Faction, DiplomaticStatus> relations = new Dictionary<Faction, DiplomaticStatus>();
    }

    public class DiplomacySystem : MonoBehaviour
    {
        public static DiplomacySystem Instance { get; private set; }
        public List<NationDiplomacy> nations = new List<NationDiplomacy>();

        private void Awake()
        {
            Instance = this;
            InitializeWorldDiplomacy();
        }

        public void InitializeWorldDiplomacy()
        {
            nations.Clear();
            nations.Add(new NationDiplomacy { faction = Faction.Uzbekistan, bloc = GlobalBloc.NonAligned_CentralAsia, goldTreasury = 1500, oilReserves = 800, nuclearWarheads = 0 });
            nations.Add(new NationDiplomacy { faction = Faction.USA, bloc = GlobalBloc.NATO_West, goldTreasury = 3000, oilReserves = 1500, nuclearWarheads = 20 });
            nations.Add(new NationDiplomacy { faction = Faction.Russia, bloc = GlobalBloc.BRICS_East, goldTreasury = 2400, oilReserves = 2200, nuclearWarheads = 25 });
            nations.Add(new NationDiplomacy { faction = Faction.Iran, bloc = GlobalBloc.Resistance_Axis, goldTreasury = 1800, oilReserves = 2000, nuclearWarheads = 3 });
            nations.Add(new NationDiplomacy { faction = Faction.China, bloc = GlobalBloc.BRICS_East, goldTreasury = 3200, oilReserves = 1200, nuclearWarheads = 15 });
            nations.Add(new NationDiplomacy { faction = Faction.Turkey, bloc = GlobalBloc.NATO_West, goldTreasury = 1700, oilReserves = 600, nuclearWarheads = 0 });
        }

        public void DeclareWar(Faction aggressor, Faction target)
        {
            var agg = nations.Find(n => n.faction == aggressor);
            if (agg != null) agg.relations[target] = DiplomaticStatus.AtWar;
            Debug.Log($"[DIPLOMATIYA] {aggressor} -> {target} ga urush e'lon qildi!");
        }

        public void SendMilitaryAid(Faction donor, Faction receiver, int goldAmount)
        {
            var d = nations.Find(n => n.faction == donor);
            var r = nations.Find(n => n.faction == receiver);
            if (d != null && r != null && d.goldTreasury >= goldAmount)
            {
                d.goldTreasury -= goldAmount;
                r.goldTreasury += goldAmount;
            }
        }
    }
}
