using UnityEngine;
using UnityEngine.UI;
using TMPro;
using WW3Command.Core;
using WW3Command.Diplomacy;
using WW3Command.Map;

namespace WW3Command.UI
{
    public class WarRoomUIController : MonoBehaviour
    {
        [Header("Yuqori Resurs Paneli")]
        public TextMeshProUGUI goldText;
        public TextMeshProUGUI oilText;
        public TextMeshProUGUI nukeText;
        public TextMeshProUGUI turnText;

        [Header("Qo'mondon Kartochkasi")]
        public Image commanderPortraitImage;
        public TextMeshProUGUI commanderNameText;
        public TextMeshProUGUI commanderTitleText;
        public TextMeshProUGUI commanderSkillText;
        public TextMeshProUGUI starsText;

        [Header("Ssenariy Tanlash")]
        public Dropdown scenarioDropdown;

        private int currentTurn = 1;
        private int selectedCommanderIndex = 0;

        private void Start()
        {
            if (HexMapManager.Instance != null) HexMapManager.Instance.GenerateScenarioMap("WW3_GLOBAL");
            ShowCommander(0);
            RefreshHUD();
        }

        public void NextCommander()
        {
            if (CommanderDatabase.Instance == null) return;
            selectedCommanderIndex = (selectedCommanderIndex + 1) % CommanderDatabase.Instance.commanders.Count;
            ShowCommander(selectedCommanderIndex);
        }

        public void ShowCommander(int index)
        {
            var list = CommanderDatabase.Instance.commanders;
            if (list.Count == 0) return;
            CommanderProfile cmd = list[index];

            if (commanderNameText != null) commanderNameText.text = cmd.fullName;
            if (commanderTitleText != null) commanderTitleText.text = $"{cmd.title} [{cmd.era}]";
            if (commanderSkillText != null) commanderSkillText.text = $"★ {cmd.specialSkillName}: {cmd.specialSkillDesc}";
            if (starsText != null)
                starsText.text = $"Piyoda:{cmd.infantryStars}★ | Tank:{cmd.armorStars}★ | Art:{cmd.artilleryStars}★ | Avia:{cmd.airForceStars}★ | Flot:{cmd.navyStars}★";

            if (PortraitLoader.Instance != null && commanderPortraitImage != null)
                PortraitLoader.Instance.LoadPortrait(cmd, commanderPortraitImage);
        }

        public void OnNextTurnClicked()
        {
            currentTurn++;
            if (DiplomacySystem.Instance != null && DiplomacySystem.Instance.nations.Count > 0)
            {
                DiplomacySystem.Instance.nations[0].goldTreasury += 250;
                DiplomacySystem.Instance.nations[0].oilReserves += 120;
            }
            RefreshHUD();
        }

        public void RefreshHUD()
        {
            if (turnText != null) turnText.text = $"YURISH: {currentTurn} (2026-YIL)";
            if (DiplomacySystem.Instance != null && DiplomacySystem.Instance.nations.Count > 0)
            {
                var player = DiplomacySystem.Instance.nations[0];
                if (goldText != null) goldText.text = $"OLTIN: {player.goldTreasury}";
                if (oilText != null) oilText.text = $"NEFT: {player.oilReserves}";
                if (nukeText != null) nukeText.text = $"YADRO: {player.nuclearWarheads}";
            }
        }
    }
}
